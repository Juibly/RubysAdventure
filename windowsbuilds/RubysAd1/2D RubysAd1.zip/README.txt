1. I completed the tutorial but did run into some issues along  the way. Some of the code given by the tutorial would have errors in it such as referring to an asset by the wrong name and a few features still don’t seem to fully work as intended. For example my health bar shrinks in all directions rather than just its length.

2. My partner for the project is Vee Czyscon and everything is going well so far.
